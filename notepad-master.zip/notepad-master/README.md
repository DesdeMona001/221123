#Notepad
##A notepad app for android
![App icon](https://raw.githubusercontent.com/mick88/notepad/master/app/src/main/res/drawable-xxhdpi/ic_launcher.png)

[![Google Play](http://developer.android.com/images/brand/en_generic_rgb_wo_45.png)](https://play.google.com/store/apps/details?id=com.mick88.notepad)

This is one of my early Android apps:
##Features
* Easily create note from clipboard text
* Automatically detected links in note
* Share note content
* Duplicate notes